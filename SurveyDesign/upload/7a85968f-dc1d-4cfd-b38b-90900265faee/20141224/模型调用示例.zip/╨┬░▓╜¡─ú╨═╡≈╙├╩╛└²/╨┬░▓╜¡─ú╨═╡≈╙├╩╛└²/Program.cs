﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace 新安江模型调用示例
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime  start=new DateTime (2014,11,1,0,0,0);
            DateTime  End=new DateTime (2014,11,2,0,0,0);
            DateTime  FEnd=new DateTime (2014,11,3,0,0,0);
            RunModel(start, End, FEnd);
        }

        static private DataTable RunModel(DateTime startDataTime, DateTime endDataTime, DateTime endShowTime)
        {
            try
            {
                DataTable resultTable = null;
                DataTable statusTable = null;
                DataTable inputDataTable;
                int Dt = 1;//计算时段为1小时
                //准备模型
                APIMODELDEMO objModel = new APIMODELDEMO(); 
                if (objModel == null)
                {
                    Console.Write ("模型准备失败！");
                    return null;
                }
                //准备参数
                Dictionary<string, double> Dparame = PrepareParames();
                //准备初始状态
                Dictionary<string, double> Dstatus = PrepareStatuses(startDataTime);
                //准备输入
                inputDataTable = PrepareInputData(startDataTime, endDataTime, endShowTime, Dt);
                //运行模型
                if (objModel != null)
                {
                    objModel.InitializeModel(Dparame, Dstatus, Dt);
                    resultTable = objModel.CalResultTable(inputDataTable, endShowTime);
                    statusTable = objModel.StatusTable;
                }
                //输出结果

                Console.Write("模型计算结果：\n");
                for (int i = 0; i < resultTable.Columns.Count; i++)
                {
                    Console.Write(resultTable.Columns[i].ColumnName + "\t");
                }
                Console.Write("\n");
                for (int i = 0; i < resultTable.Rows.Count; i++)
                {
                    for (int j = 0; j < resultTable.Columns.Count; j++)
                    {
                        Console.Write(resultTable.Rows[i][j].ToString() + "\t");
                    }
                    Console.Write("\n");
                }
                Console.Write("模型状态结果：\n");
                for (int i = 0; i < statusTable.Columns.Count; i++)
                {
                    Console.Write(statusTable.Columns[i].ColumnName + "\t");
                }
                Console.Write("\n");
                for (int i = 0; i < statusTable.Rows.Count; i++)
                {
                    for (int j = 0; j < statusTable.Columns.Count; j++)
                    {
                        Console.Write(statusTable.Rows[i][j].ToString() + "\t");
                    }
                    Console.Write("\n");
                }
                Console.Read();
                return resultTable;
            }
            catch (Exception NewE)
            {
                Console.Write("运行模型错误！" + NewE.ToString());
                return null;
            }

        }

        static private Dictionary<string, double> PrepareParames()
        {
            //准备参数
            Dictionary<string, double> Dparame = new Dictionary<string, double>();
           
            Dparame.Add("A", 10);
            Dparame.Add("B", 5);
            Dparame.Add("C", 100);
           
            return Dparame;
        }

        static private Dictionary<string, double> PrepareStatuses(DateTime startTime)
        {
            //准备初始状态
            Dictionary<string, double> Dstatus = new Dictionary<string, double>();
            Dstatus.Add("PE", 11);
            Dstatus.Add("EP", 22);
            return Dstatus;
        }

        static public DataTable PrepareInputData(DateTime startDataTime, DateTime endDataTime, DateTime endFDataTime, int Dt)
        {
            DataTable inputDataTable;
            TimeSpan dataTimeSpan = endDataTime - startDataTime;
            int dataTimeLength = (int)dataTimeSpan.TotalHours / Dt + 1;
            inputDataTable = new DataTable("模型输入");
            inputDataTable.Columns.Add("时间", typeof(DateTime));
            inputDataTable.Columns.Add("降雨", typeof(double));
            inputDataTable.Columns.Add("蒸发", typeof(double));
            Random RAD = new Random();
            for (int i = 0; i < dataTimeLength; i++)
            {
                DataRow NewDataRow = inputDataTable.NewRow();
                NewDataRow[0] = startDataTime.AddHours(i * Dt);
                NewDataRow[1] = RAD.Next (100);
                NewDataRow[2] = RAD.Next (10);
                inputDataTable.Rows.Add(NewDataRow);
            }
            return inputDataTable;
        }
       

    }
}
