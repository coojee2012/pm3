﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace 新安江模型调用示例
{
    public interface IModel
    {
        string ModelName { get; }
        string ModelType { get; }
        int DataSrcCount { get; }
        int DataTgtCount { get; }
        int ParamCount { get; }
        int StatusCount { get; }
        string Explain { get; }
        string[,] Parameters { get; }
        string[,] Statuses { get; }
        string[,] Inputs { get; }
        string[,] Outputs { get; }
        bool InitializeModel(Dictionary<string, double> Parameters, Dictionary<string, double> Status0, int Dt);// int FT
        DataTable CalResultTable(DataTable realInputTable, DateTime FEndTime);
        //计算，input为输入表，FendTime为最后需要运行到的时间，返回计算结果表
        DataTable OutputTable { get; }//获取计算结果表
        DataTable StatusTable { get; }//获取计算过程中的状态表
        DataTable InputTable { get; }

    }
}
