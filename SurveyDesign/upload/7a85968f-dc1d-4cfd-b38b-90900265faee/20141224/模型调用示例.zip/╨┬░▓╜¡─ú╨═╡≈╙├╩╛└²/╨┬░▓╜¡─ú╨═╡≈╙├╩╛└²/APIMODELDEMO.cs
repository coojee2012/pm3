﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
namespace 新安江模型调用示例
{
    class APIMODELDEMO:IModel
    {
        #region 模型的基本信息，注册模型时需要
        readonly string modelName = "API模型";
        readonly string modelType = "流域水文模型";
        readonly int dataSrcCount = 2;
        readonly int dataTgtCount = 1;
        readonly int paramCount = 3;
        readonly int statusCount = 2;
        readonly string explain = "这是一个示例";
        readonly string[,] parameters = { { "A", "雨量系数" }, { "B", "蒸发系数" }, { "C", "常数" }};
        readonly string[,] statuses = { { "PE", "雨蒸差" }, { "EP", "雨蒸和" }};
        readonly string[,] inputs = { { "P", "降雨" }, { "E", "蒸发" } };
        readonly string[,] outputs = { { "CQ", "流域出流" } };

        #endregion
        #region IModel 成员,注册模型是需要

        public string ModelName
        {
            get { return modelName; }
        }
        public string ModelType
        {
            get { return modelType; }
        }
        public int DataSrcCount
        {
            get { return dataSrcCount; }
        }
        public int DataTgtCount
        {
            get { return dataTgtCount; }
        }
        public int ParamCount
        {
            get { return paramCount; }
        }
        public int StatusCount
        {
            get { return statusCount; }
        }
        public string Explain
        {
            get { return explain; }
        }
        public string[,] Parameters
        {
            get { return parameters; }
        }
        public string[,] Statuses
        {
            get { return statuses; }
        }
        public string[,] Inputs
        {
            get { return inputs; }
        }
        public string[,] Outputs
        {
            get { return inputs; }
        }
        #endregion

        public bool InitializeModel(Dictionary<string, double> Parameters, Dictionary<string, double> Status0, int Dt)
        {
            try
            {
                dt = Dt;
                A = Parameters["A"]; B = Parameters["B"]; C= Parameters["C"]; 
                PE = Status0["PE"]; EP = Status0["EP"]; 
                return true;
            }
            catch
            {
                return false;
            }
        }
        public DataTable CalResultTable(DataTable InputTable, DateTime FEndTime)
        {
            try
            {
                int datalength = InputTable.Rows.Count;
                double XAJQ;
                double CalculateRain = 0;
                double CalculateEvap = 0;
                DateTime EndTimeTemp=new DateTime();
                outputTable = new DataTable();
                outputTable.Columns.Add("时间", typeof(DateTime));
                outputTable.Columns.Add("出流量", typeof(double));

                if (datalength > 0)
                {
                    EndTimeTemp = (DateTime)InputTable.Rows[0][0];
                }
                for (int i = 0; i < datalength ; i++)
                {
                    CalculateRain = (double)(InputTable.Rows[i][1]);
                    CalculateEvap = (double)(InputTable.Rows[i][2]);

                    XAJQ =(A*CalculateRain - B*CalculateEvap)*1000/3.6+C;//逐时段计算
                    DataRow NewEndRow = outputTable.NewRow();
                    NewEndRow[0] = EndTimeTemp;
                    NewEndRow[1] = XAJQ;
                    outputTable.Rows.Add(NewEndRow);

                    DataRow NewStatusRow = statusTable.NewRow();
                    NewStatusRow[0] = EndTimeTemp;
                    NewStatusRow[1] = CalculateRain - CalculateEvap;
                    NewStatusRow[2] = CalculateRain + CalculateEvap;
                    statusTable.Rows.Add(NewStatusRow);
                    EndTimeTemp = EndTimeTemp.AddHours(dt);
                }
                while (EndTimeTemp < FEndTime)
                {
                    Random RRRRR = new Random();
                    CalculateRain = 100;//RRRRR.Next(30);
                    CalculateEvap = 50;// RRRRR.Next(30);
                    XAJQ = (A * CalculateRain - B * CalculateEvap) * 1000 / 3.6 + C;//逐时段计算
                    EndTimeTemp = EndTimeTemp.AddHours(dt);
                    DataRow NewEndRow = outputTable.NewRow();
                    NewEndRow[0] = EndTimeTemp;
                    NewEndRow[1] = XAJQ;
                    outputTable.Rows.Add(NewEndRow);
                    DataRow NewStatusRow = statusTable.NewRow();
                    NewStatusRow[0] = EndTimeTemp;
                    NewStatusRow[1] = CalculateRain - CalculateEvap;
                    NewStatusRow[2] = CalculateRain + CalculateEvap;

                    statusTable.Rows.Add(NewStatusRow);
                }
            }
            catch (Exception ee)
            {
                throw ee;
            }
            return outputTable;
        }

        private double A, B,C;
        private int dt, L;

        private double PE, EP;//状态
        private DataTable inputTable;
        private DataTable outputTable;
        private DataTable statusTable;


        public DataTable OutputTable
        {
            get
            {
                return outputTable;
            }
        }
        public DataTable StatusTable
        {
            get
            {
                return statusTable;
            }
        }
        public DataTable InputTable
        {
            get { return inputTable; }
        }

        public APIMODELDEMO()
        {
            inputTable = new DataTable("模型输入");
            outputTable = new DataTable("模型输出");
            statusTable = new DataTable("模型运行状态");
            inputTable.Columns.Add("时间", typeof(DateTime));
            inputTable.Columns.Add("降雨量", typeof(double));
            inputTable.Columns.Add("蒸发量", typeof(double));
            outputTable.Columns.Add("时间", typeof(DateTime));
            outputTable.Columns.Add("出流量", typeof(double));
            statusTable.Columns.Add("时间", typeof(DateTime));
            statusTable.Columns.Add("PE", typeof(double));
            statusTable.Columns.Add("EP", typeof(double));
        }

      
       

    }
}